# QA Execution Summary

- **Project / release:**
- **Tester:**
- **Execution date:**
- **Environment:**
- **Build / commit:**

## Results

| Metric | Count |
|---|---:|
| Planned | |
| Passed | |
| Failed | |
| Blocked | |
| Not run | |
| Defects raised | |

## Risk summary
- Critical user journeys covered:
- Known gaps:
- Environment limitations:
- Highest-risk open defects:

## Recommendation
Summarize the evidence against agreed exit criteria. Distinguish product failures from infrastructure or test-data issues. Do not claim release readiness without appropriate scope and evidence.
