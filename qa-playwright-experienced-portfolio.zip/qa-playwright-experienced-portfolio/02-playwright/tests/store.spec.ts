import { test, expect } from '@playwright/test';

const username = 'standard_user';
const password = 'secret_sauce';

test.describe('SauceDemo critical user journeys', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('valid login displays inventory @smoke', async ({ page }) => {
    await page.getByPlaceholder('Username').fill(username);
    await page.getByPlaceholder('Password').fill(password);
    await page.getByRole('button', { name: 'Login' }).click();

    await expect(page).toHaveURL(/inventory\.html/);
    await expect(page.locator('[data-test="inventory-list"]')).toBeVisible();
  });

  test('invalid password shows an error', async ({ page }) => {
    await page.getByPlaceholder('Username').fill(username);
    await page.getByPlaceholder('Password').fill('incorrect_password');
    await page.getByRole('button', { name: 'Login' }).click();

    await expect(page.locator('[data-test="error"]')).toBeVisible();
    await expect(page.locator('[data-test="error"]')).toContainText(
      /username and password|do not match/i,
    );
  });

  test('adding and removing a product updates the cart', async ({ page }) => {
    await page.getByPlaceholder('Username').fill(username);
    await page.getByPlaceholder('Password').fill(password);
    await page.getByRole('button', { name: 'Login' }).click();

    await page.getByRole('button', { name: 'Add to cart' }).first().click();
    await expect(page.locator('.shopping_cart_badge')).toHaveText('1');

    await page.getByRole('link', { name: 'Shopping Cart' }).click();
    await expect(page.locator('.cart_item')).toHaveCount(1);

    await page.getByRole('button', { name: 'Remove' }).click();
    await expect(page.locator('.cart_item')).toHaveCount(0);
  });

  test('checkout requires last name', async ({ page }) => {
    await page.getByPlaceholder('Username').fill(username);
    await page.getByPlaceholder('Password').fill(password);
    await page.getByRole('button', { name: 'Login' }).click();

    await page.getByRole('button', { name: 'Add to cart' }).first().click();
    await page.getByRole('link', { name: 'Shopping Cart' }).click();
    await page.getByRole('button', { name: 'Checkout' }).click();

    await page.getByPlaceholder('First Name').fill('QA');
    await page.getByPlaceholder('Last Name').fill('');
    await page.getByPlaceholder('Zip/Postal Code').fill('SW1A');
    await page.getByRole('button', { name: 'Continue' }).click();

    await expect(page.locator('[data-test="error"]')).toBeVisible();
  });
});
