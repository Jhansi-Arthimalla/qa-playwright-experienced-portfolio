import { test, expect } from '@playwright/test';

test('GET public demo post returns expected JSON fields', async ({ request }) => {
  const response = await request.get('https://jsonplaceholder.typicode.com/posts/1');

  expect(response.status()).toBe(200);
  expect(response.headers()['content-type']).toContain('application/json');

  const body = await response.json();
  expect(body.id).toBe(1);
  expect(body.title).toEqual(expect.any(String));
  expect(body.userId).toEqual(expect.any(Number));
});
