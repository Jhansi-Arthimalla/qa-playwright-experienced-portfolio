# Playwright + TypeScript UI Automation

## Coverage
- Successful login
- Invalid login error
- Add/remove cart item
- Checkout required-field validation

## Design choices
- Playwright Test runner and built-in fixtures
- Role/placeholder locators where practical
- Web-first assertions
- Independent test setup
- HTML report, screenshots, video, and trace on failure
- Smoke tag for a critical login path

## Prerequisites
- Node.js 20+ recommended
- npm
- Network access to install packages and access the demo application

## Install and run
```bash
npm install
npx playwright install chromium
npm test
```

Run headed:
```bash
npm run test:headed
```

Run smoke test:
```bash
npm run test:smoke
```

Open HTML report after a run:
```bash
npm run report
```

## Next steps
- Add Page Object Model only when it improves reuse and readability.
- Add Firefox and WebKit projects.
- Add CI pipeline and upload reports/traces as artifacts.
- Add test data fixtures and environment configuration.
- Add accessibility checks where relevant.
- Keep credentials and tokens out of source control.

These tests use a public demo website and may need maintenance if its UI changes.
