# API Testing with Playwright

The sample API test uses Playwright's `request` fixture with JSONPlaceholder, a public demo API.

Run:
```bash
npm test
```
from `02-playwright`, after installing dependencies. The API spec lives alongside the UI specs in `tests/api.spec.ts`.

Checks:
- HTTP status is 200
- Content type indicates JSON
- Returned post ID and title are present

Treat the endpoint as a practice service, not a production contract.
