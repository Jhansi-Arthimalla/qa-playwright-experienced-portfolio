# Example Defect Reports — Illustrative Only

> These are reporting examples, not confirmed defects in SauceDemo. Verify behavior before logging a real issue. Replace actual results, severity, and evidence with what you observe.

## DEF-001 — Invalid credentials do not produce expected feedback

- **Area:** Authentication
- **Priority:** Proposed P2, subject to team triage
- **Precondition:** Login page is available.
- **Steps:**
  1. Enter a documented demo username.
  2. Enter an incorrect password.
  3. Select Login.
- **Expected:** Access is denied and a clear error message is displayed.
- **Actual:** Record the observed behavior; do not assume a defect exists.
- **Impact:** Users may not understand why sign-in failed if feedback is absent or unclear.
- **Evidence:** Screenshot and browser details, if behavior differs from expectation.

## DEF-002 — Checkout validation allows progression with missing required data

- **Area:** Checkout
- **Priority:** Proposed P1/P2 depending on impact and requirements
- **Precondition:** User is signed in and cart contains a product.
- **Steps:**
  1. Open the cart and start checkout.
  2. Leave a required field blank.
  3. Select Continue.
- **Expected:** Checkout remains on the information step and displays a validation message.
- **Actual:** Record the observed behavior.
- **Impact:** Incomplete order information may prevent a valid checkout or create confusing user experience.
- **Evidence:** Screenshot or trace if a mismatch is reproducible.

## Reporting discipline
- If actual behavior matches expectations, mark the test passed and do not file a defect.
- Separate product defects from environment/setup failures.
- Avoid assigning severity solely from intuition; use team definitions and business impact.
