# Test Strategy — Practice E-commerce Application

## Objective
Validate critical user journeys and demonstrate a risk-based approach to testing an e-commerce workflow.

## Risk-based priorities
**High risk**
- Authentication and access control
- Checkout progression and order confirmation
- Cart state and product selection

**Medium risk**
- Required-field validation
- Product listing and navigation
- Cart removal and quantity/state updates

**Lower risk for this demo**
- Cosmetic presentation and non-critical text

Priorities should be revisited using actual business impact, likelihood, and release context.

## Scope
In scope: login, inventory, cart, checkout validation, and order completion.
Out of scope: payment gateway processing, performance/load testing, penetration testing, and production integrations.

## Test levels and types
- Functional and negative testing
- Smoke and regression testing
- Exploratory testing around state changes and navigation
- UI automation for repeatable critical paths
- API response validation against a public demo endpoint

## Test environment
- App: https://www.saucedemo.com/
- Browser: record actual browser and version
- OS: record actual operating system
- Date/build: record actual execution details

## Entry criteria
- Test environment is reachable.
- Demo credentials and test data are available.
- Acceptance expectations for the tested flow are understood.

## Exit criteria
- Planned tests have execution status.
- Critical-path tests are passing or have documented blockers.
- Reproducible failures have evidence and linked defect records.
- Known limitations and residual risks are summarized.

## Test data and evidence
Use demo-only data. Capture screenshots, trace files, console/network evidence when useful. Do not store credentials, tokens, or personal data in the repository.

## Reporting
Report total, passed, failed, blocked, and not-run tests; link defects; describe environment issues separately from product defects.
