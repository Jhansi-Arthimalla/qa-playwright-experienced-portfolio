# Defect Report Template

- **ID / Title:**
- **Product / feature:**
- **Environment:** OS, browser/version, device
- **Build / release:**
- **Severity:** Critical / High / Medium / Low
- **Priority:** P1 / P2 / P3 / P4, using team definitions
- **Preconditions:**
- **Steps to reproduce:**
  1.
  2.
  3.
- **Expected result:**
- **Actual result:**
- **Reproducibility:** Always / Intermittent / Once
- **Evidence:** Screenshot, Playwright trace, logs, network details
- **Impact / risk:**
- **Workaround:**
- **Linked test case / requirement:**
- **Status / owner:**

Keep reports concise, objective, and independently reproducible. Remove secrets and personal data from evidence.
