# QA Engineering Portfolio — Manual, API & Playwright Automation

**Experienced QA portfolio | Manual Testing | Playwright | TypeScript | API Testing | CI-ready test design**

This repository is a structured portfolio template for an experienced QA professional. It demonstrates test strategy, risk-based test design, reproducible defect reporting, UI automation with Playwright Test and TypeScript, and API validation.

> **Important:** The included tests and defects are examples. Run the suite, replace placeholders with your real execution details, and report only verified defects. Do not claim these examples represent production or client work unless they do.

## Portfolio projects

### 1. Risk-based manual testing — SauceDemo
Practice app: https://www.saucedemo.com/

Includes:
- Scope, risks, entry/exit criteria, and test approach
- Functional, negative, regression, and exploratory scenarios
- CSV test cases and execution-status fields
- Defect-report examples and a reusable defect template

See `01-manual-testing/`.

### 2. UI automation — Playwright + TypeScript
Uses Playwright Test, fixtures, resilient locators, assertions, and isolated browser contexts.

Scenarios:
- Successful login
- Invalid login feedback
- Add and remove a product from the cart
- Checkout required-field validation

See `02-playwright/`.

### 3. API testing — Playwright APIRequestContext
Uses a public demo API to validate response status, content type, and JSON data. See `03-api-testing/`.

### 4. Quality reporting
A test summary template and example metrics are in `04-quality-reporting/`.

## Run the Playwright suite

Requirements: Node.js 20+ recommended.

```bash
cd 02-playwright
npm install
npx playwright install chromium
npm test
```

To view the HTML report:

```bash
npm run report
```

The demo site and public API are third-party practice services. Test results may vary if they change or become unavailable.

## Skills demonstrated
- Risk-based testing and test strategy
- Functional, negative, regression, and exploratory testing
- Test design and traceability
- Defect lifecycle and reproducible reporting
- Playwright Test with TypeScript
- UI and API assertions
- Test isolation, readable locators, and maintainable test structure
- Test reporting and CI-oriented workflows

## Recommended next improvements
- Add GitHub Actions CI after local runs pass.
- Capture failure screenshots and traces.
- Add tags for smoke and regression suites.
- Expand cross-browser coverage.
- Add accessibility checks and test data strategy where relevant.
- Link test cases to requirements and defects.

## About
This repository is intended to demonstrate my QA approach through reproducible practice examples. Replace this paragraph with a concise summary of your actual domain experience, responsibilities, measurable impact, and tools.

## Disclaimer
This portfolio uses public practice services and is not affiliated with their owners. Only test systems you own or have explicit permission to test.
